#!//bin/bash
#Don't forget to set the environment
inputadauth=/home/ubuntu/Locations/ouname/logs/adauth.log
inputadadmin=/home/ubuntu/Locations/ouname/logs/adadmin.log
inputav=/home/ubuntu/Locations/ouname/logs/symantec.log
inputfw=/home/ubuntu/Locations/ouname/logs/asa.log
inputvpnca=/home/ubuntu/Locations/ouname/logs/asavpnca.log
inputvpnaz=/home/ubuntu/Locations/ouname/logs/asavpnaz.log
inputvpnwa=/home/ubuntu/Locations/ouname/logs/asavpnwa.log
inputvpnor=/home/ubuntu/Locations/ouname/logs/asavpnor.log
inputvpnnv=/home/ubuntu/Locations/ouname/logs/asavpnnv.log
inputids=/home/ubuntu/Locations/ouname/logs/snort.log
inputdns=/home/ubuntu/Locations/ouname/logs/infobloxdns.log
inputdhcp=/home/ubuntu/Locations/ouname/logs/infobloxdhcp.log
collectorip=127.0.0.1
domain=udomain
IFS=,

echo "Simulator Started..."
while true; do echo 'Press CTRL+C  or CTRL+Z to STOP!';
currenttime=$(date +%H)

shuf /home/ubuntu/Locations/ouname/users.txt -o /home/ubuntu/Locations/ouname/users.txt
input=/home/ubuntu/Locations/ouname/users.txt

if [[ "$currenttime" > 9 || "$currenttime" < 17 ]]; then
sleep 1;
else
sleep 15;
fi
while read -r uname uip utype ulocation umac uwstation ugname ulastname unotused
do
	echo "Simulating activity for.... $uname ($utype $ulocation user) -> $uip"

		#AD login logs (in the morning and after lunch)
		if [[ "$currenttime" > 9 || "$currenttime" < 11 ]]; then
				today=$(date +"%b %d %T")
				tstamp=$(date +"%a %b %d %T %Y")
				wintime=$(date +"%Y%m%d%H%M%S.%N-000")
		printf "{\"eventCode\":4624,\"computerName\":\"${uwstation}.udomain\",\"insertionStrings\":[\"S-1-0-0\",\"-\",\"-\",\"0x0\",\"usid\",\"${uname}\",\"UDOMAIN\",\"0x1616c047\",\"3\",\"Kerberos\",\"Kerberos\",\"-\",\"{d64f0d98-5d0f-f04b-64f9-e7fff1e55bc4}\",\"-\",\"-\",\"0\",\"0x0\",\"-\",\"${uip}\",\"52869\",\"%%1833\",\"-\",\"-\",\"-\",\"%%1843\",\"0x0\",\"%%1842\"],\"timeGenerated\":\"${wintime}\"}" | nc -w1 -u $collectorip 12006
		fi


		if [[ "$currenttime" > 13 || "$currenttime" < 14 ]]; then
				today=$(date +"%b %d %T")
				tstamp=$(date +"%a %b %d %T %Y")
				wintime=$(date +"%Y%m%d%H%M%S.%N-000")
		printf "{\"eventCode\":4624,\"computerName\":\"${uwstation}.udomain\",\"insertionStrings\":[\"S-1-0-0\",\"-\",\"-\",\"0x0\",\"usid\",\"${uname}\",\"UDOMAIN\",\"0x1616c047\",\"3\",\"Kerberos\",\"Kerberos\",\"-\",\"{d64f0d98-5d0f-f04b-64f9-e7fff1e55bc4}\",\"-\",\"-\",\"0\",\"0x0\",\"-\",\"${uip}\",\"52869\",\"%%1833\",\"-\",\"-\",\"-\",\"%%1843\",\"0x0\",\"%%1842\"],\"timeGenerated\":\"${wintime}\"}" | nc -w1 -u $collectorip 12006
		fi

		#Firewall logs
		today=$(date +"%b %d %Y %T")
		for((n=1;n<=$(( 1 + $RANDOM % 5));n++))
			do
			replace=$(shuf -n 1 $inputfw)
			replace="${replace/uname/$uname}"
			echo $today".000 udomain_ASA: ${replace/uip/$uip}" | nc -w1 -u $collectorip 12001
		done

		#AD Authentication logs
			today=$(date +"%b %d %T")
			tstamp=$(date +"%a %b %d %T %Y")
			wintime=$(date +"%Y%m%d%H%M%S.%N-000")
				for((n=0;n<=$(( -1 + $RANDOM % 3));n++))
					do
						replace=$(shuf -n 1 $inputadauth)
						replace="${replace/tstamp/$tstamp}"
						replace="${replace/wintime/$wintime}"
						replace="${replace/uname/$uname}"
						replace="${replace/uname/$uname}"
						replace="${replace/ugname/$ugname}"
						replace="${replace/ulastname/$ulastname}"
						replace="${replace/udomain/$domain}"
						replace="${replace/uwstation/$uwstation}"
						replace="${replace/uwstation/$uwstation}"
						echo "${replace/uip/$uip}" | nc -w1 -u $collectorip 12006
					done
					
		#AD Admin Activity logs
		if [[ "$currenttime" > 10 || "$currenttime" < 11 ]]; then
			today=$(date +"%b %d %T")
			tstamp=$(date +"%a %b %d %T %Y")
			wintime=$(date +"%Y%m%d%H%M%S.%N-000")
				for((n=998;n<=$(($RANDOM % 1001));n++))
					do
						replace=$(shuf -n 1 $inputadadmin)
						replace="${replace/tstamp/$tstamp}"
						replace="${replace/wintime/$wintime}"
						replace="${replace/uname/$uname}"
						replace="${replace/uname/$uname}"
						replace="${replace/ugname/$ugname}"
						replace="${replace/ulastname/$ulastname}"
						replace="${replace/udomain/$domain}"
						replace="${replace/uwstation/$uwstation}"
						replace="${replace/uwstation/$uwstation}"
						echo "${replace/uip/$uip}" | nc -w1 -u $collectorip 12006
					done
		fi


		#DHCP logs
		today=$(date +"%b %d %Y %T ")
		for((n=0;n<=$(( -1 + $RANDOM % 4));n++))
			do
			replace=$(shuf -n 1 $inputdhcp)
			replace="${replace/umac/$umac}"
			replace="${replace/uwstation/$uwstation}"
			echo $today"udomain_DHCP ${replace/uip/$uip}" | nc -w1 -u $collectorip 12005
		done

		#VPN Logs for VPN Users Version 2
		today=$(date +"%b %d %Y %T")
		#echo "currenttime is "$currenttime
		if [[ "$currenttime" > 10 || "$currenttime" < 12 ]]; then
		randomvalue=$RANDOM
		if [[ "$randomvalue" -gt 31000 ]]; then
			#do
				if [ $ulocation == 'ca' ]; then
					replace=$(shuf -n 1 $inputvpnca)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'az' ]; then
					replace=$(shuf -n 1 $inputvpnaz)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'or' ]; then
					replace=$(shuf -n 1 $inputvpnor)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'wa' ]; then
					replace=$(shuf -n 1 $inputvpnwa)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'nv' ]; then
					replace=$(shuf -n 1 $inputvpnnv)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				
				today=$(date +"%b %d %T")
				tstamp=$(date +"%a %b %d %T %Y")
				wintime=$(date +"%Y%m%d%H%M%S.%N-000")
				rndsrv=$[RANDOM%3+1]
				printf "{\"eventCode\":4624,\"computerName\":\"${uwstation}.udomain\",\"insertionStrings\":[\"S-1-0-0\",\"-\",\"-\",\"0x0\",\"usid\",\"${uname}\",\"UDOMAIN\",\"0x1616c047\",\"3\",\"Kerberos\",\"Kerberos\",\"-\",\"{d64f0d98-5d0f-f04b-64f9-e7fff1e55bc4}\",\"-\",\"-\",\"0\",\"0x0\",\"-\",\"${uip}\",\"52869\",\"%%1833\",\"-\",\"-\",\"-\",\"%%1843\",\"0x0\",\"%%1842\"],\"timeGenerated\":\"${wintime}\"}" | nc -w1 -u $collectorip 12006		
			#done
			fi
		fi
		
			
		randomvalue=$RANDOM
		if [[ "$randomvalue" -gt 33000 ]]; then
			#do
				if [ $ulocation == 'ca' ]; then
					replace=$(shuf -n 1 $inputvpnca)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'az' ]; then
					replace=$(shuf -n 1 $inputvpnaz)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'or' ]; then
					replace=$(shuf -n 1 $inputvpnor)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'wa' ]; then
					replace=$(shuf -n 1 $inputvpnwa)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				if [ $ulocation == 'nv' ]; then
					replace=$(shuf -n 1 $inputvpnnv)
					uip=$(awk -F"." '{print $1"."7"."$3"."$4}'<<<$uip)
					replace="${replace/uip/$uip}"
					echo $today".000 udomain_VPN: ${replace/uname/$uname}" | nc -w1 -u $collectorip 12001
				fi
				
				today=$(date +"%b %d %T")
				tstamp=$(date +"%a %b %d %T %Y")
				wintime=$(date +"%Y%m%d%H%M%S.%N-000")
				rndsrv=$[RANDOM%3+1]
				printf "{\"eventCode\":4624,\"computerName\":\"${uwstation}.udomain\",\"insertionStrings\":[\"S-1-0-0\",\"-\",\"-\",\"0x0\",\"usid\",\"${uname}\",\"UDOMAIN\",\"0x1616c047\",\"3\",\"Kerberos\",\"Kerberos\",\"-\",\"{d64f0d98-5d0f-f04b-64f9-e7fff1e55bc4}\",\"-\",\"-\",\"0\",\"0x0\",\"-\",\"${uip}\",\"52869\",\"%%1833\",\"-\",\"-\",\"-\",\"%%1843\",\"0x0\",\"%%1842\"],\"timeGenerated\":\"${wintime}\"}" | nc -w1 -u $collectorip 12006		
			#done
			fi
	
		#IDS logs
		today=$(date +"%b %d %Y %T ")
		for((n=998;n<=$(($RANDOM % 1001));n++))
			do
			replace=$(shuf -n 1 $inputids)
			echo $today"udomain_IDS suricata[9354]: ${replace/uip/$uip}" | nc -w1 -u $collectorip 12003
		done

		#DNS logs
		today=$(date +"%b %d %Y %T ")
		for((n=0;n<=$(( -1 + $RANDOM % 4));n++))
			do
			replace=$(shuf -n 1 $inputdns)
			echo "udomain_DNS "$today" 0.0.0.0  ${replace/uip/$uip}" | nc -w1 -u $collectorip 12004
		done

#		#AV logs
#		today=$(date +"%b %d %Y %T ")
#		for((n=999;n<=$(( -1 + $RANDOM % 1000));n++))
#			do
#			replace=$(shuf -n 1 $inputav)
#			replace="${replace/uname/$uname}"
#			replace="${replace/tstamp/$today}"
#			echo $today" ${replace/uwstation/$uwstation}" | nc -w1 -u $collectorip 12007
#		done

		randomvalue=$RANDOM
		if [[ "$randomvalue" -gt 34000 ]]; then
			#do
			replace=$(shuf -n 1 $inputav)
			replace="${replace/uname/$uname}"
			replace="${replace/tstamp/$today}"
			echo $today" ${replace/uwstation/$uwstation}" | nc -w1 -u $collectorip 12007
			fi

done <"$input"
done
