﻿##Use this script to build the initial domain structure.

Function Get-TimeStamp {
    
    return "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
    
}

$LogFileDate = $(Get-Date).tostring("yyyyMMdd_HHmmss")
$LogFile = "$(Get-Location)\$LogFileDate-$(gc env:computername)-DomainBuildStep.log"

Function Log-Write
{
    Param ([string]$logstring)
    Add-Content $LogFile -value $logstring
}

Function GeneratePassword
{
    # How many Characters Minimum?
    $Length=15
    # Create a password choosing everything from Character 34 to 127
    1..$Length | foreach{ $Password+=([char]((Get-Random 93)+34))}
    # Convert to a Secure String
    $Password=Convertto-SecureString $Password -asplaintext -force
    Return $Password
}

Clear-Host
Write-Host "`n"
Write-Host "`n"
Write-Host "You can exit from this script at any time by entering CTRL-C." -BackgroundColor Green -ForegroundColor Black
Write-Host "`n This script will create a new Windows domain, while prompting you for the domain name and OU structure to use.  
 The host that the script is run from will bnecome a domain controller for this domain."
#Write-Host " The script will also populate the domain with users and groups so that it may be used for demo or testing purposes."
Write-Host "`n You should run this script on a Microsoft Windows Server 2019 host that is not currently a domain controller.  A dedicated host is recommended." -ForegroundColor Magenta
Write-Host "`n The server must have a static IP assigned.  If you have not assigned a static IP, exit now by using CTRL-C and set a static IP address." -ForegroundColor Magenta
Write-Host "`n"
Write-Host "`n It is normal for some messages that appear to be errors to be displayed when creating the first domain controller for a new domain.  
 When the script has completed, you should see the status of the domain controller promotion on the screen.  If it is Success, 
 then reboot as directed and continue with the second script.  An error log will be created and located in the same folder as 
 this script that can be used for troubleshooting issues with the domain controller installation."
#Write-Host "`n"
Write-Host "`n"

$Response = Read-Host "`n Do you want to continue? (y/n) "
If ($Response -ne "y") {exit}

Do {

$Confirmation = "n"
$DomainName = Read-Host -Prompt "What fully qualified name would you like to use for this domain?  Press ENTER to use the default value of anonymoose.dev.  Otherwise, enter in a FQDN:"
If ([string]::IsNullOrWhiteSpace($DomainName))
    {
     $DomainName = "anonymoose.dev"
     }

If ($DomainName -match '\w+\.\w+') {

        $Check = $true
        $DomainNetbiosname,$TLD = ($DomainName).split(".")
               
        } Else {

        Write-Host " `n   ** You have not entered a fully qualified domain name.  Your input must be in the format of DomainName.TopLevelDomain.  Please try again. ** `n" -ForegroundColor Red
        $Check = $false
        
    }
    
    If ($check) {

        Write-Host "`n The domain name you want to use is:  $DomainName `n" -ForegroundColor Green
    
        $confirmation = Read-Host "Is this correct? (y/n)"

    }


} Until ($Confirmation -eq "y")

Write-Host "Domain services are being installed onto this host.  This will take a few minutes.  When the install finishes, this window may close."
Write-Host "It is normal when configuraing a domain controller for some errors to appear."
Write-Host "You need to reboot this host before running the second build script." -BackgroundColor Green -ForegroundColor Black

#$DomainName = "anonymoose.dev"
$SafeModePwd = GeneratePassword
Log-Write "$(Get-TimeStamp) Log File: $LogFile"
Log-Write "$(Get-TimeStamp) Starting domain build for domain $DomainName."
Log-Write "$(Get-TimeStamp) Installing AD Domain Services Management Tools."
Log-Write "$(Get-TimeStamp) Running this command: Install-WindowsFeature -name AD-Domain-Services -IncludeManagementTools -IncludeAllSubFeature -LogPath $LogFile"
Install-WindowsFeature -name AD-Domain-Services -IncludeManagementTools -IncludeAllSubFeature -LogPath $LogFile
Log-Write "$(Get-TimeStamp) Importing the AD Module into Powershell for the rest of the commands"
Import-Module ActiveDirectory >> $LogFile

#Install-ADDSForest -DomainName $DomainName -CreateDNSDelegation -InstallDNS
Log-Write "$(Get-TimeStamp) Running this command: Install-ADDSForest –SkipPreChecks –CreateDnsDelegation:$False –DomainName $DomainName –DomainNetbiosname $DomainNETBIOSName –InstallDns:$True –Logpath ‘C:\Windows\NTDS’ `
–NoRebootOnCompletion:$True –SysvolPath ‘C:\Windows\SYSVOL’ –SafeModeAdministratorPassword $SafeModePwd –force"
Install-ADDSForest –SkipPreChecks –CreateDnsDelegation:$False –DomainName $DomainName –DomainNetbiosname $DomainNETBIOSName –InstallDns:$True –Logpath ‘C:\Windows\NTDS’ `
–NoRebootOnCompletion:$True –SysvolPath ‘C:\Windows\SYSVOL’ –SafeModeAdministratorPassword $SafeModePwd –force

#Install-ADDSForest -DomainName $DomainName -InstallDns -SafeModeAdministratorPassword $SafeModePwd -Confirm:$false -NoRebootOnCompletion -LogPath $LogFile >> $LogFile

Log-Write "`n `n $(Get-TimeStamp) Ending domain build for domain $DomainName. `n"
Log-Write "$(Get-TimeStamp) Reboot this host if you have not already done so before continuing with the next script."
Write-Host "You need to reboot this host before running the second build script." -BackgroundColor Green -ForegroundColor Black