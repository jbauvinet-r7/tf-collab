﻿   ##Use this script to build the initial domain structure.

   Function Get-TimeStamp {
    
    return "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
    
}

$LogFileDate = $(Get-Date).tostring("yyyyMMdd_HHmmss")
$LogFile = "C:\s3-downloads\Locations\Log_Sim_Scripts\Log_Sim_Scripts\$LogFileDate-$(gc env:computername)-DomainBuildOutStep.log"

Function Log-Write
{
    Param ([string]$logstring)
    Add-Content $LogFile -value $logstring
}


Function GenerateStrongPassword ([Parameter(Mandatory=$true)][int]$PasswordLength)
{
Add-Type -AssemblyName System.Web
$PassComplexCheck = $false
do {
$newPassword=[System.Web.Security.Membership]::GeneratePassword($PasswordLength,3)
If ( ($newPassword -cmatch "[A-Z\p{Lu}\s]") `
-and ($newPassword -cmatch "[a-z\p{Ll}\s]") `
-and ($newPassword -match "[\d]") `
-and ($newPassword -match "[^\w]")
)
{
$PassComplexCheck=$True
}
} While ($PassComplexCheck -eq $false)
return $newPassword
}


Function Create-Domain-User
{
    Param ([string]$UserName,[string]$FirstName,[string]$LastName,[string]$UserPassword,[string]$OU)
   
    try {
        ##Attempt to find the username
        $UserAccount = Get-AdUser -Identity $UserName
        if ($Username.Length -gt 0) {
            ##If the username is found throw an error and exit
            Log-Write "$(Get-TimeStamp) The username $UserName already exist in $OU"
            return
            }
        }
    catch {
        New-ADUser `
            -SamAccountName $UserName `
            -UserPrincipalName "$UserName@$DomainName" `
            -Name "$FirstName $LastName" `
            -GivenName $FirstName `
            -Surname $LastName `
            -Enabled $True `
            -DisplayName "$LastName, $FirstName" `
            -Path $OU `
            -AccountPassword (convertto-securestring $UserPassword -AsPlainText -Force) -ChangePasswordAtLogon $True -ErrorAction Stop
            $created  += @($UserName)
        Log-Write "$(Get-TimeStamp) $FirstName $LastName account created in $OU."
    } #end of try-catch
} #end of function

Function Test-PasswordForDomain {
    Param ([Parameter(Mandatory=$true)][string]$Password)
    If ($Password.Length -lt 6) {
        Write-Host -ForegroundColor Red "$(Get-TimeStamp) ERROR The password must be at least six characters long.  The entered password was only " $Password.Length " characters long."
        return $false
    }
     If (
                 ($Password -cmatch "[A-Z\p{Lu}\s]") `
            -and ($Password -cmatch "[a-z\p{Ll}\s]") `
            -and ($Password -match "[\d]") `
            -and ($Password -match "[^\w]")  
        ) { 
            return $true
        }
     Else {
        Write-Host -ForegroundColor Red "$(Get-TimeStamp) ERROR The password did not meet the complexity requirements.  Try again."
        return $false
        } 

} #end of Test-PasswordForDomain Function

Function Create-OU-Structure {
    Param ([Parameter(Mandatory=$true)][string]$BaseOuName)
    #Read the data in each field in each row and assign to the variable
    $name = $BaseOuName
    $path = (Get-ADDomain -Current LocalComputer).DistinguishedName
    $ouDN = "OU=$name,$path"
    #Check to see if the OU already exists
    try {
        Get-ADOrganizationalUnit -Identity $ouDN | Out-Null
        Log-Write "$(Get-TimeStamp) OU '$ouDN' already exists."
    }
    #If the OU does not exist, create it.
     catch [Microsoft.ActiveDirectory.Management.ADIdentityNotFoundException] {
        New-ADOrganizationalUnit -Name $name -Path $path
        Log-Write "$(Get-TimeStamp) Created OU '$name' in path '$path'."
        
        #create Admins OU
        $name = "Admins"
        New-ADOrganizationalUnit -Name $name -Path $ouDN
        Log-Write "$(Get-TimeStamp) Created OU '$name' in path '$ouDN'."
        $LocationOU = "OU=$name,$ouDN"
       
        $group = "$BaseOUName Server Admins Group"
        New-ADGroup -Name $group -Path $LocationOU -Description "Server Admins Group" -GroupCategory Security -GroupScope Global -ManagedBy "MMoose"
        Log-Write "$(Get-TimeStamp) Created a group named $group in $ouDN."
        $group = "$BaseOUName Desktop Admins Group"
        New-ADGroup -Name $group -Path $LocationOU -Description "Desktop Admins Group" -GroupCategory Security -GroupScope Global -ManagedBy "MMoose"
        Log-Write "$(Get-TimeStamp) Created a group named $group in $ouDN."
        
        $name = "Service Accounts"
        New-ADOrganizationalUnit -Name $name -Path $ouDN
        Log-Write "$(Get-TimeStamp) Created OU '$name' in path '$ouDN'."
        $LocationOU = "OU=$name,$ouDN"
       
        $group = "$BaseOUName Service Accounts Group"
        New-ADGroup -Name $group -Path $LocationOU -Description "Service Accounts Group" -GroupCategory Security -GroupScope Global -ManagedBy "MMoose"
        Log-Write "$(Get-TimeStamp) Created a group named $group in $ouDN."
         
        $name = "Users"
        New-ADOrganizationalUnit -Name $name -Path $ouDN
        Log-Write "$(Get-TimeStamp) Created OU '$name' in path '$ouDN'."
        $LocationOU = "OU=$name,$ouDN"
        
        $group = "$BaseOUName Remote Employees"
        New-ADGroup -Name $group -Path $LocationOU -GroupCategory Security -GroupScope Global -ManagedBy "MMoose"
        Log-Write "$(Get-TimeStamp) Created a group named $group in $ouDN."  
        $group = "$BaseOUName Vendors"
        New-ADGroup -Name $group -Path $LocationOU -Description "Vendors Group" -GroupCategory Security -GroupScope Global -ManagedBy "MMoose"
        Log-Write "$(Get-TimeStamp) Created a group named $group in $ouDN."  

       
    }  #end of catch

} #end of function

Function Get-Location-And-Run-Builds {
      Param ([Parameter(Mandatory=$true)][string]$DefaultOuName,$RunNum,$UserList)
      Do {
        $OuName = $DefaultOUName
        $confirmation = "y"
        } Until ($Confirmation -eq "y")
        Create-OU-Structure $OuName
        $OUTrimmedName = $OuName -replace '\s',''
        $NewFolder = "C:\s3-downloads\Locations\Log_Sim_Scripts\Log_Sim_Scripts\Locations\$OUTrimmedName"
        If (Test-Path $NewFolder) {
            Log-Write "$(Get-TimeStamp) The folder $NewFolder already existed and was not created."
        }
            Else
        {
            New-Item $NewFolder -ItemType "Directory"
            Log-Write "$(Get-TimeStamp) The folder $NewFolder was created."
        }
        $UserLocation = $OuName -replace '\s',''
        Build-Out-Users $NewFolder $OuName $RunNum $UserList
        Create-Log-Generator-Bash-Script $NewFolder $OuName $RunNum
   
}    #end of Build-Out-Ous Function

Function Create-Log-Generator-Bash-Script {
Param ([string]$ScriptLocation,[string]$Location,$RunNum)
        #copy the default script to new location
        $ScriptToUse = $RunNum.ToString() + "_simulator_build.sh"
        $LogsFolder = "C:\s3-downloads\Locations\Log_Sim_Scripts\Log_Sim_Scripts\LogGeneratorScripts\" + $RunNum.ToString() + "_logs"
        $TemplateScript = "C:\s3-downloads\Locations\Log_Sim_Scripts\Log_Sim_Scripts\LogGeneratorScripts\$ScriptToUse"
        $FinalScriptforLocation = "$ScriptLocation\$Location" + "_simulator.sh"
        
        If (Test-Path $FinalScriptforLocation) {
            Log-Write "$(Get-TimeStamp) File $FinalScriptforLocation already exists and was not copied from the build repository."
        }
            Else
        {
            Copy-Item $TemplateScript -Destination $FinalScriptForLocation 
            Log-Write "$(Get-TimeStamp) File $FinalScriptforLocation was copied from the build repository."
            #Copy Log Files
            Copy-Item -Path $LogsFolder -Destination "$ScriptLocation\logs" -Force -Recurse
            Log-Write "$(Get-TimeStamp) Folder $ScriptLocation\logs was created from the build repository."
        }
             
        #replace the locationname
        $ReplacedContent = ((Get-Content -Path $FinalScriptforLocation) -replace "ouname",$Location | Set-Content -Path $FinalScriptforLocation) 

        #replace the domain name
        $shortdomainName = (Get-ADDomain -Current LocalComputer).NetBiosName
        $fqdndomainName = (Get-ADDomain -Current LocalComputer).DNSRoot
        $tld = $fqdndomainName.Split('.')[1]
        $ReplacedContent = ((Get-Content -Path $FinalScriptforLocation) -creplace "UDOMAIN",$fqdndomainName.ToUpper() | Set-Content -Path $FinalScriptforLocation)
        $ReplacedContent = ((Get-Content -Path $FinalScriptforLocation) -creplace "udomain",$fqdndomainName.ToLower() | Set-Content -Path $FinalScriptforLocation)
        #sed -i -e 's/\r$//' scriptname.sh
        #$FileContents = Get-Content -Raw $ReplacedContent | Set-Content -NoNewline -Encoding UTF8 $ReplacedContent ($FileContents -replace "`r`n","`n")
        #$FileContents = Get-Content -Raw $ReplacedContent | Set-Content -NoNewline $ReplacedContent ($FileContents -replace "`r`n","`n")
        $FinalSimulatorScript = (Get-Content -Raw -Path $FinalScriptforLocation).Replace(",`r`n", [System.Environment]::NewLine) | Set-Content $FinalScriptforLocation
        #Replace in the log files
       
        ForEach ($File in (Get-ChildItem -Path "$ScriptLocation\logs" -File)) {
            (Get-Content "$ScriptLocation\logs\$File") -replace "ouname",$Location | Set-Content "$ScriptLocation\logs\$File"
            (Get-Content "$ScriptLocation\logs\$File") -creplace "UDOMAIN",$shortdomainName.ToUpper() | Set-Content "$ScriptLocation\logs\$File"
            (Get-Content "$ScriptLocation\logs\$File") -creplace "udomain",$shortdomainName.ToLower() | Set-Content "$ScriptLocation\logs\$File"
            (Get-Content "$ScriptLocation\logs\$File") -creplace "UTLD",$tld.ToUpper() | Set-Content "$ScriptLocation\logs\$File"
            (Get-Content "$ScriptLocation\logs\$File") -creplace "utld",$tld.ToLower() | Set-Content "$ScriptLocation\logs\$File"
        }
        
}    #end of Create-Log-Generator-Bash-Script

Function Create-Users-From-File {
Param ([string]$ListofUsersFile,[string]$Location)
    $Users = Import-Csv $ListofUsersFile -header Username,IP,Type,Division,MacAddress,WorkstationName,Firstname,Lastname

    $path = (Get-ADDomain -Current LocalComputer).DistinguishedName
    $userDN = "OU=Users,OU=$Location,$path"

    ForEach ($User in $Users) {
        #Write-Host "User is " $User.Username
        $UPassword = GenerateStrongPassword (16)
        Create-Domain-User $User.Username $User.Firstname $User.Lastname $UPassword $userDN      
    } #end of ForEach Loop

}    #end of Create-Users-From-File Function

Function Create-Log-Generator-User-List {
Param ([string]$OutputUserList,[string]$InputUserList,[string]$Location,$RunNum)
    #account,hostip,type,location,macaddr,wsname,fname,lastname,usersid
    $IPAddr1Value = 10
    $IPAddr2Value = $RunNum
    $IPAddr3Value = 0
    $IPAddr4Value = 0
    
    $Users = Import-CSV $InputUserList -Header FirstName,LastName -Delimiter " "
 

    ForEach ($User in $Users) {
        $FirstName = $User.FirstName
        $LastName = $User.LastName
        $Account = ($Firstname.Substring(0,1) + $LastName).ToLower()
        #$Account = $Account -replace '\s+',''
        $IPAddr4Value = $IPAddr4Value + 1
        If ($IPAddr4Value -lt 255) {
            $HostIP = "$IPAddr1Value.$IPAddr2Value.$IPAddr3Value.$IPAddr4Value"
            If ($IPAddr3Value -lt 10) {$Mac3Value = "0" + $IPAddr3Value} 
                Else {$Mac3Value = $IPAddr3Value}
            $MacAddr = "00:00:00:00:00:" + $Mac3Value + ":" + $IPAddr4Value
           }
        else {
            #The last octet is full
            $IPAddr3Value = $IPAddr3Value + 1
            If ($IPAddr3Value -gt 254) {
                $IPAddr3Value = 0
                $IPAddr2Value = $IPAddr2Value + 1
            }
            $IPAddr4Value = 1
            $HostIP = "$IPAddr1Value.$IPAddr2Value.$IPAddr3Value.$IPAddr4Value"
            If ($IPAddr3Value -lt 10) {$Mac3Value = "0" + $IPAddr3Value} 
                Else {$Mac3Value = $IPAddr3Value}
            $MacAddr = "00:00:00:00:00:" + $Mac3Value + ":" + $IPAddr4Value
            
        }
        $UType = "local"
        #Generate a SID
        #sid S-1-5-21-2133283647-1115780651-2130403006-11950
        $FirstValue = Get-Random -Minimum 1 -Maximum 2999999999
        $SecondValue = Get-Random -Minimum 1 -Maximum 2999999999
        $ThirdValue = Get-Random -Minimum 1 -Maximum 2999999999
        $LastValue = Get-Random -Minimum 1 -Maximum 100000
        $FirstValue = ([string]$FirstValue).PadLeft(10,"0")
        $SecondValue = ([string]$SecondValue).PadLeft(10,"0")
        $ThirdValue = ([string]$ThirdValue).PadLeft(10,"0")
        $LastValue = ([string]$LastValue).PadLeft(5,"0")
        $UserSID = "S-1-5-21-$FirstValue-$SecondValue-$ThirdValue-$LastValue"
        Switch ($RunNum) {
        #Location 1 is Austin
        1{
             Switch ($IPAddr4Value){
                {$_ -in 1,2} {$LocCode = "la"}
                {$_ -in 3,4} {$LocCode = "nm"}
                {$_ -in 5,6} {$LocCode = "co"}
                default {$LocCode = "tx"}
            }
        }#end of Texas location
        #Lcation 2 is Boston
        2{
             Switch ($IPAddr4Value){
                {$_ -in 1,2} {$LocCode = "ny"}
                {$_ -in 3,4} {$LocCode = "mn"}
                {$_ -in 5,6} {$LocCode = "vt"}
                {$_ -in 7,8} {$LocCode = "nh"}
                default {$LocCode = "ma"}
            }
        }#end of Boston location
        #Location 3 is Rio.  No VPN locations are configured in the bash script.
        3{$LocCode = "br"}
        #Lcation 4 is San Deigo
        4{
             Switch ($IPAddr4Value){
                {$_ -in 1,2} {$LocCode = "az"}
                {$_ -in 3,4} {$LocCode = "or"}
                {$_ -in 5,6} {$LocCode = "wa"}
                {$_ -in 7,8} {$LocCode = "nv"}
                default {$LocCode = "ca"}
            }
        }#end of San Diego location
        #Location 5 is Manchester, no VPN locations are configured in the bash script
        5{$LocCode = "uk"}
        #Lcation 6 is Melbourne
        6{
             Switch ($IPAddr4Value){
                {$_ -in 1,2} {$LocCode = "ru"}
                {$_ -in 3,4} {$LocCode = "cn"}
                default {$LocCode = "au"}
            }
        }#end of Melbourne location

        } #end of main RunNum Switch
        $WSName = "ws-$LocCode-$Account"
        $NewLine = "$Account,$HostIP,$UType,$LocCode,$MacAddr,$WSName,$FirstName,$LastName,$UserSID"
        $NewLine = $NewLine -replace '\s+',''
        Add-Content -Path $OutputUserList $NewLine
        #$newRow = New-Object psObject -Property @{ FirstName = $FirstName ; LastName = $LastName }
        #Export-CSV $OutputUserList -InputObject $newRow -Append -Force -NoTypeInformation
        
    } #end of ForEach Loop
   
   }    #end of Create-Users-From-File Function

Function Get-ListType {
    #https://fossbytes.com/tools/random-name-generator
    Write-Host "`n"
    $type=Read-Host "Which list would you like to use?  Don't hit yourself in the head!  Each list can only be used once, so remember which one you select now.
    1 - Famous Entertainers - 1,367 Names
    2 - Famous Authors with 1,212 Names
    3 - American Actors with 954 Names
    4 - English-Type Generic Names - Very Small 1 - 50 Names
    5 - English-Type Generic Names - Very Small 2 - 61 Names
    6 - English-Type Generic Names - Small 1 - 77 Names
    7 - English-Type Generic Names - Small 2 - 184 Names
    8 - English-Type Generic Names - Medium 1 - 1344 Names
    9 - English-Type Generic Names - Medium 2 - 2452 Names
    10 - English-Type Generic Names - Medium 3 - 1042 Names
    11 - English-Type Generic Names - Medium 4- 670 Names
    12 - English-Type Generic Names - Large 1 - 4335 Names
    13 - English-Type Generic Names - Large 2 - 5203 Names
    14 - English-Type Generic Names - Large 3 - 6506 Names
    15 - English-Type Generic Names - Mega - 75,571 Names
    16 - German-Type Generic Names - Small - 92 Names
    17 - German-Type Generic Names - Medium - 451 Names
    18 - German-Type Generic Names - Mega - 97,853 Names
    19 - Spanish-Type Generic Names - Small - 333 Names
    20 - Spanish-Type Generic Names - Medium - 1352 Names
    21 - Spanish-Type Generic Names - Large - 6109 Names
    22 - Spanish-Type Generic Names - Mega - 92,127 Names
    23 - French-Type Generic Names - Small - 259 Names
    24 - French-Type Generic Names - Medium - 995 Names
    25 - French-Type Generic Names - Large - 4,125 Names
    26 - French-Type Generic Names - Mega - 77,280 Names
    Please choose"

    Switch ($type){
        1 {$choice="FamousEntertainers.txt"}
        2 {$choice="FamousAuthors.txt"}
        3 {$choice="AmericanActors.txt"}
        4 {$choice="EnglishNames-VerySmallLIst1.txt"}
        5 {$choice="EnglishNames-VerySmallLIst2.txt"}
        6 {$choice="EnglishNames-SmallList1.txt"}
        7 {$choice="EnglishNames-SmallList2.txt"}
        8 {$choice="EnglishNames-MediumList1.txt"}
        9 {$choice="EnglishNames-MediumList2.txt"}
        10 {$choice="EnglishNames-MediumList3.txt"}
        11 {$choice="EnglishNames-MediumList4.txt"}
        12 {$choice="EnglishNames-LargeList1.txt"}
        13 {$choice="EnglishNames-LargeList2.txt"}
        14 {$choice="EnglishNames-LargeList3.txt"}
        15 {$choice="EnglishNames-MegaList.txt"}
        16 {$choice="GermanUsers-Small.txt"}
        17 {$choice="GermanUsers-Medium.txt"}
        18 {$choice="GermanUsers-Mega.txt"}
        19 {$choice="SpanishNames-SmallList.txt"}
        20 {$choice="SpanishNames-MediumList.txt"}
        21 {$choice="SpanishNames-LargeList.txt"}
        22 {$choice="SpanishNames-MegaList.txt"}
        23 {$choice="FrenchNames-SmallList.txt"}
        24 {$choice="FrenchNames-MediumList.txt"}
        25 {$choice="FrenchNames-LargeList.txt"}
        26 {$choice="FrenchNames-MegaList.txt"}
    }
    return $choice
}

Function Build-Out-Users {
     Param ([string]$UserFolder,[string]$Location,$RunNum,$UserList)
     $FinalUserListforOU = "$UserFolder\users.txt"
     
     If (Test-Path $FinalUserListforOU) {
             Log-Write "$(Get-TimeStamp) The file $FinalUserListforOU already exists."
        }
            Else
        {
            New-Item $FinalUserListforOU -ItemType "File"
             Log-Write "$(Get-TimeStamp) The file $FinalUserListforOU was created."
        }

     $ListToUse = $UserList
     $ListofInputUsers = "C:\s3-downloads\Locations\Log_Sim_Scripts\Log_Sim_Scripts\UserLists\$ListToUse"
     
     Create-Log-Generator-User-List $FinalUserListforOU $ListofInPutUsers $Location $RunNum
     Create-Users-From-File $FinalUserListforOU $Location
   
}    #end of Buld-Out-Users function


Log-Write "$(Get-TimeStamp) Log File: $LogFile"
Log-Write "$(Get-TimeStamp) Starting domain structure build for $(gc env:computername)."
Import-Module ActiveDirectory 
#Get the password for the MMoose Account
Clear-Host

Write-Host "Creating the domain structure.  This may take a few minutes."
Write-Host "`n"
Write-Host "This script will create six OUs and populate each with users.  At the same time, the six log generator tools will be created."
Write-Host "You will asked to input names for each location.  You may use the default OU names or enter your own.  In order for the VPN"
Write-Host "locations to make sense, you should use location names close to the originals.  For example, instead of Austin, you might use"
Write-Host "Texas, Louisiana, or another state/city in this geographic region.  Instead of Manchester, you might use London or Paris."
Write-Host "`n"
Write-Host "After entering in the location, you will be asked to select users from a choice of available user lists.  If you choose a large or"
Write-Host "mega list, it will take a few minutes for these users to be created."
Write-Host "`n"
Write-Host "Please note that it is normal for the user generation to sometimes cause some errors to be displayed on the screen because the"
Write-Host "password that the script generates is not complex enough or the account name is not formatted correctly.  You may safely ignore"
Write-Host "these messages."
Write-Host "`n"
Write-Host "`n"
Log-Write "$(Get-TimeStamp) Configuring the OU structure for domain $DomainName."

#Clear-Host
Get-Location-And-Run-Builds "Austin" 1 "EnglishNames-MediumList1.txt"
Get-Location-And-Run-Builds "Boston" 2 "FamousEntertainers.txt"
Get-Location-And-Run-Builds "Rio" 3 "SpanishNames-MediumList.txt"
Get-Location-And-Run-Builds "SanDiego" 4 "EnglishNames-MediumList4.txt"
Get-Location-And-Run-Builds "Melbourne" 5 "EnglishNames-MediumList2.txt"
Get-Location-And-Run-Builds "Reading" 6 "EnglishNames-LargeList1.txt" 